#pragma once

#include <JuceHeader.h>

class SpectralLimiterAudioProcessor  : public juce::AudioProcessor
{
public:
    SpectralLimiterAudioProcessor();
    ~SpectralLimiterAudioProcessor() override;

    void prepareToPlay (double sampleRate, int samplesPerBlock) override;
    void releaseResources() override;

    bool isBusesLayoutSupported (const BusesLayout& layouts) const override;

    void processBlock (juce::AudioBuffer<float>&, juce::MidiBuffer&) override;

    juce::AudioProcessorEditor* createEditor() override;
    bool hasEditor() const override;

    const juce::String getName() const override;

    bool acceptsMidi() const override;
    bool producesMidi() const override;
    bool isMidiEffect() const override;
    double getTailLengthSeconds() const override;

    int getNumPrograms() override;
    int getCurrentProgram() override;
    void setCurrentProgram (int index) override;
    const juce::String getProgramName (int index) override;
    void changeProgramName (int index, const juce::String& newName) override;

    void getStateInformation (juce::MemoryBlock& destData) override;
    void setStateInformation (const void* data, int sizeInBytes) override;

    float getGainReduction() const noexcept { return lastGainReduction.get(); }
    
    static constexpr int fftOrder = 10;
    static constexpr int fftSize = 1 << fftOrder;
    void getNextFFTBlock (float* outputData) noexcept { juce::FloatVectorOperations::copy (outputData, fftGetData.data(), fftSize / 2); }
    bool isFFTDataReady() const noexcept { return fftDataReady.get(); }
    void clearFFTReadyFlag() noexcept { fftDataReady.set (false); }

    juce::AudioProcessorValueTreeState apvts;
    juce::String currentPresetName = "INIT";

    // ---- editor UI state ----
    // Deliberately live here, on the processor, rather than on the editor or
    // canvas: many hosts destroy and recreate the editor component every time
    // the plugin's UI window is closed and reopened, so anything stored only
    // on the editor resets to its default each time, even though nothing
    // about the plugin itself changed -- which is exactly what was happening
    // to the accent colour, the settings-panel-open state, and the window
    // size. The processor persists for the whole life of the plugin instance
    // (and, via getStateInformation/setStateInformation, across a full
    // project save/reload too), so that's where this belongs instead.
    int lastAccentIndex = 0;
    bool lastSettingsPanelOpen = false;
    bool lastRainbowModeOn = false;
    int lastEditorWidth = 920, lastEditorHeight = 596;
private:
    juce::AudioProcessorValueTreeState::ParameterLayout createParameterLayout();

    double currentSampleRate = 44100.0;
    
    juce::AudioBuffer<float> lookAheadBuffer;
    int writeIndex = 0;
    int lookAheadSamples = 0;

    float envLeft = 0.0f;
    float envRight = 0.0f;

    juce::Atomic<float> lastGainReduction { 0.0f };

    juce::dsp::StateVariableTPTFilter<float> lowPassFilterL, lowPassFilterR;
    juce::dsp::StateVariableTPTFilter<float> highPassFilterL, highPassFilterR;

    juce::dsp::FFT forwardFFT { fftOrder };
    juce::dsp::WindowingFunction<float> window { fftSize, juce::dsp::WindowingFunction<float>::hann };
    
    std::array<float, fftSize> fftFifo;
    std::array<float, fftSize * 2> fftBuffer;
    std::array<float, fftSize / 2> fftGetData;
    int fftFifoIndex = 0;
    juce::Atomic<bool> fftDataReady { false };

    // ---- output dither ----
    // TPDF dither at the chosen bit depth, with an optional 1st-order noise-shaping
    // feedback loop for "Shaped Noise Dither". See processBlock() / applyDither().
    juce::Random ditherRandom;
    float noiseShapeErrorL = 0.0f, noiseShapeErrorR = 0.0f;
    float applyDither (float sample, float& shapeError, int ditherMode) noexcept;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (SpectralLimiterAudioProcessor)
};
