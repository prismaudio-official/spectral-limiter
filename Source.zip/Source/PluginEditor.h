#pragma once

#include <JuceHeader.h>
#include "PluginProcessor.h"
#include "NeumorphicLookAndFeel.h"

//==============================================================================
// A single custom LookAndFeel that renders every control as a flat, minimal,
// glowing surface. Strictly two base colours drive the whole UI (a near-black
// for dark mode, a light neutral grey for light mode); every other value is a
// tint, shade, or alpha of those two plus the achromatic "ink" (white in dark
// mode, near-black in light mode) used for text, glow rings and LEDs.
//==============================================================================
class SkeuoLookAndFeel : public juce::LookAndFeel_V4
{
public:
    SkeuoLookAndFeel();

    void drawRotarySlider (juce::Graphics&, int x, int y, int width, int height,
                            float sliderPos, float startAngle, float endAngle, juce::Slider&) override;
    void drawLinearSlider (juce::Graphics&, int x, int y, int width, int height,
                            float sliderPos, float minSliderPos, float maxSliderPos,
                            juce::Slider::SliderStyle, juce::Slider&) override;
    void drawLabel (juce::Graphics&, juce::Label&) override;
    void drawToggleButton (juce::Graphics&, juce::ToggleButton&, bool isHighlighted, bool isDown) override;
    void drawButtonBackground (juce::Graphics&, juce::Button&, const juce::Colour& backgroundColour,
                                bool isHighlighted, bool isDown) override;
    void drawComboBox (juce::Graphics&, int width, int height, bool isButtonDown,
                        int buttonX, int buttonY, int buttonW, int buttonH, juce::ComboBox&) override;
    void positionComboBoxText (juce::ComboBox&, juce::Label&) override;
    void drawPopupMenuBackground (juce::Graphics&, int width, int height) override;
    void drawPopupMenuItem (juce::Graphics&, const juce::Rectangle<int>& area, bool isSeparator, bool isActive,
                             bool isHighlighted, bool isTicked, bool hasSubMenu, const juce::String& text,
                             const juce::String& shortcutKeyText, const juce::Drawable* icon,
                             const juce::Colour* textColour) override;

    void setLightMode (bool lightMode)       { isLightMode = lightMode; }
    void setAccentColor (juce::Colour color) { accentColour = color; }

private:
    bool isLightMode = false;
    juce::Colour accentColour { juce::Colours::white };
};

//==============================================================================
// Spectrum readout, styled as a flat glowing screen (no bezel chrome).
//==============================================================================
class LiveSpectrumVisualizer : public juce::Component, private juce::Timer
{
public:
    LiveSpectrumVisualizer (SpectralLimiterAudioProcessor& p);
    void paint (juce::Graphics& g) override;
    void resized() override { backgroundCache = {}; }
    void setLightMode (bool lightMode) { isLightMode = lightMode; backgroundCache = {}; repaint(); }
    void setAccentColor (juce::Colour c) { accentColour = c; repaint(); }
    void setPanelColor (juce::Colour c) { panelColour = c; backgroundCache = {}; repaint(); }
    void setRefreshRate (int hz) { startTimerHz (hz); }

private:
    void timerCallback() override;
    // The panel fill + bezel + inner-shadow never change frame to frame (only
    // the FFT trace does), but this component repaints 15-45x/sec on its own
    // timer -- recomputing those melatonin blur shadows every single frame was
    // pure waste, and became very visible once the whole UI started being
    // rendered through a scaling transform (see SpectralLimiterAudioProcessorEditor)
    // where every repaint anywhere in the tree forces a full re-rasterise.
    // Cached once, only rebuilt when the bounds or theme actually change.
    juce::Image backgroundCache;
    void rebuildBackgroundCache();

    SpectralLimiterAudioProcessor& processor;
    std::array<float, SpectralLimiterAudioProcessor::fftSize / 2> fftData;
    bool isLightMode = false;
    juce::Colour accentColour { juce::Colours::white };
    juce::Colour panelColour { 0xFF121216 };
};

//==============================================================================
// Gain-reduction meter, styled as a segmented LED strip that glows as it fills.
//==============================================================================
class SmoothAttenuationMeter : public juce::Component
{
public:
    SmoothAttenuationMeter (SpectralLimiterAudioProcessor& p) : processor (p) {}

    void resized() override { backgroundCache = {}; }
    void setLightMode (bool lightMode)   { isLightMode = lightMode; backgroundCache = {}; repaint(); }
    void setAccentColor (juce::Colour c) { accentColour = c; repaint(); }
    void setPanelColor (juce::Colour c)  { panelColour = c; backgroundCache = {}; repaint(); }
    void updateValue (float valDb)       { currentGRDb = valDb; repaint(); }

    void paint (juce::Graphics& g) override;

private:
    // The track groove and its border are static -- only the lit-segment count
    // changes per frame -- so that part is cached and only the segments/glow
    // are redrawn every repaint. The dB number labels are also static but are
    // deliberately *not* cached -- see drawLabels() -- so they stay crisp when
    // the UI is scaled up via the resize transform.
    juce::Image backgroundCache;
    juce::Rectangle<float> cachedMeterArea;
    void rebuildBackgroundCache();
    void drawLabels (juce::Graphics& g) const;

    SpectralLimiterAudioProcessor& processor;
    float currentGRDb = 0.0f;
    bool isLightMode = false;
    juce::Colour accentColour { juce::Colours::white };
    juce::Colour panelColour { 0xFF121216 };
};

//==============================================================================
// The ceiling topology slider (0=hard, 1=soft, 2=tape, 3=brickwall) pulls
// toward whichever of those four values the drag is currently nearest, with
// the pull getting stronger the closer it gets -- close to a mode, it's easy
// to land exactly on it; further away (near the midpoint between two modes),
// the slider tracks the mouse normally. It never hard-snaps: the value is
// always a continuous function of the drag position, just weighted toward the
// four named points rather than uniform across the whole range.
//==============================================================================
class MagneticTopologySlider : public juce::Slider
{
public:
    using juce::Slider::Slider;

    double snapValue (double attemptedValue, juce::Slider::DragMode dragMode) override
    {
        juce::ignoreUnused (dragMode);

        static const double anchors[] = { 0.0, 1.0, 2.0, 3.0 };
        const double hardSnapRadius = 0.07; // close enough that it just locks on, exactly
        const double pullRadius = 0.45;     // wide field of pull -- reaches most of the
                                             // way to the midpoint between adjacent modes
                                             // (which are 1.0 apart, so 0.5 is the limit)

        for (double anchor : anchors)
        {
            double distance = std::abs (attemptedValue - anchor);

            if (distance < hardSnapRadius)
                return anchor; // genuinely locked on, not just asymptotically close

            if (distance < pullRadius)
            {
                // Cubic easing: stays gentle near the outer edge of the field so
                // it still tracks the mouse normally out there, then ramps up
                // hard approaching the anchor -- a noticeably stronger pull than
                // a quadratic curve gives, without ever visibly teleporting.
                double t = 1.0 - (distance / pullRadius);
                double pullStrength = t * t * t;
                return attemptedValue + (anchor - attemptedValue) * pullStrength;
            }
        }

        return attemptedValue;
    }
};

//==============================================================================
// The entire UI, laid out at a fixed native size (see PluginCanvas::nativeWidth/
// nativeHeight below) exactly as before. It's a plain Component now rather than
// the AudioProcessorEditor itself -- see SpectralLimiterAudioProcessorEditor
// below, which hosts one of these and rescales it as a single unit so resizing
// the plugin window rescales the whole UI (chrome included), not just the
// margin around a fixed-size island of content.
//==============================================================================
class PluginCanvas  : public juce::Component, private juce::Timer
{
public:
    PluginCanvas (SpectralLimiterAudioProcessor&);
    ~PluginCanvas() override;

    static constexpr int nativeWidth = 920, nativeHeight = 596;

    void paint (juce::Graphics&) override;
    void paintOverChildren (juce::Graphics&) override;
    void resized() override;
    void mouseUp (const juce::MouseEvent& event) override;

private:
    void timerCallback() override;
    void updateSpectralControlsVisibility();
    void checkHoverStates();
    void updateThemeColors();
    void resetAllParameters();
    void selectAccentColour (int index);
    juce::Font getBrandFont (float height, bool isBold);

    // ---- preset save/load ----
    void refreshPresetList();
    void promptSavePreset();
    void savePresetAs (const juce::String& name);
    juce::File getPresetFolder() const;

    // ---- drawing helpers (paint-time chrome that isn't a Component) ----
    void drawChassis (juce::Graphics& g);
    void drawHeaderBackground (juce::Graphics& g);
    void drawHeaderForeground (juce::Graphics& g);
    void drawLogoMark (juce::Graphics& g, juce::Rectangle<float> bounds, bool lightModeActive);
    void drawPanelBackground (juce::Graphics& g, juce::Rectangle<int> bounds);
    void drawPanelForeground (juce::Graphics& g, juce::Rectangle<int> bounds, const juce::String& title);
    void drawSettingsOverlay (juce::Graphics& g);

    // Sits in z-order between the main UI (below, now always visible) and the
    // settings controls (above, brought to front in resized()): dims the main
    // UI and draws the settings box's own background chrome. A real child
    // component rather than paint()/paintOverChildren() drawing, because that's
    // the only way in JUCE to get something to render strictly between two
    // other layers of children.
    class SettingsBackdrop : public juce::Component
    {
    public:
        explicit SettingsBackdrop (PluginCanvas& o) : owner (o) {}
        void paint (juce::Graphics& g) override;
    private:
        PluginCanvas& owner;
    };
    SettingsBackdrop settingsBackdrop;

    // The header, all four panels, and the status bar are static -- none of
    // that chrome changes frame to frame, only attenuationMeter and visualizer
    // (both children within it) do, on their own timers. Because the whole
    // canvas is rendered through a scaling transform (see
    // SpectralLimiterAudioProcessorEditor), JUCE can't repaint just those two
    // children in isolation -- a repaint anywhere in a transformed subtree forces
    // the *entire* subtree to be re-rasterised, which meant every melatonin blur
    // shadow across the whole main view was being recomputed 15-45 times a
    // second for no reason. This cache is what actually fixes that: the static
    // chrome is rendered once into an image and reused until something (theme,
    // accent colour, layout) genuinely changes it.
    juce::Image mainViewCache;
    void rebuildMainViewCache();
    void invalidateMainViewCache() { mainViewCache = {}; }

    SpectralLimiterAudioProcessor& audioProcessor;
    SkeuoLookAndFeel customLAF;
    // Soft-UI variant applied to the rotary knobs and a few chrome buttons;
    // declared right after customLAF so it's destroyed after the components
    // that reference it (members are torn down in reverse declaration order).
    NeumorphicLookAndFeel neumorphicLAF;
    LiveSpectrumVisualizer visualizer;
    SmoothAttenuationMeter attenuationMeter;

    // Logo artwork -- swapped based on theme. Loaded from BinaryData (see the
    // constructor); falls back to the drawn vector mark if not yet wired up.
    std::unique_ptr<juce::Drawable> logoDark, logoLight;

    juce::Slider gainKnob, ceilingKnob, releaseKnob, bassElasticityKnob, preSatKnob, scUnlinkSlider, freqMinKnob, freqMaxKnob, mixKnob, outGainKnob;
    MagneticTopologySlider topologySlider;
    juce::Label gainLabel, ceilingLabel, releaseLabel, bassLabel, preSatLabel, scLabel, freqMinLabel, freqMaxLabel, mixLabel, outGainLabel;
    juce::Label topoHardLabel, topoSoftLabel, topoTapeLabel, topoBrickLabel;

    juce::ToggleButton deltaButton, spectralButton, themeToggleGroup;
    juce::TextButton linktreeButton, closeSettingsButton;
    // hidden easter egg: an invisible toggle tucked in the settings box's
    // bottom-right corner that spins the accent colour through the spectrum
    juce::TextButton rainbowEasterEgg;
    juce::Label infoPanel;

    // ---- preset bar (centred in the header, between the logo and the meter) ----
    juce::ComboBox presetBox;
    juce::TextButton presetPrevButton, presetNextButton, presetSaveButton;

    // ---- settings-panel-only controls (hidden unless the panel is open) ----
    juce::ToggleButton tooltipsToggle;
    juce::ComboBox ditherBox;
    juce::ToggleButton analyzerFastBtn, analyzerNormBtn, analyzerSlowBtn;
    juce::TextButton resetButton;
    juce::Label settingsGeneralLabel, settingsDitherLabel, settingsAnalyzerLabel, settingsAccentLabel;

    // accent-colour picker: index 0 is the adaptive default (white in dark / ink in light)
    juce::TextButton accentSwatches[9];
    int selectedAccentIndex = 0;

    bool showTooltips = true;
    float meterDecayStep = 0.7f;

    using Attachment = juce::AudioProcessorValueTreeState::SliderAttachment;
    using ButtonAttachment = juce::AudioProcessorValueTreeState::ButtonAttachment;
    using ComboAttachment = juce::AudioProcessorValueTreeState::ComboBoxAttachment;

    std::unique_ptr<Attachment> gainAttach, ceilingAttach, topoAttach, releaseAttach, bassAttach, preSatAttach, scAttach, freqMinAttach, freqMaxAttach, mixAttach, outGainAttach;
    std::unique_ptr<ButtonAttachment> deltaAttach, spectralAttach, themeAttach;
    std::unique_ptr<ComboAttachment> ditherAttach;

    float currentGainReductionValue = 0.0f;
    bool isSettingsPanelOpen = false;
    bool rainbowModeOn = false;
    float rainbowHue = 0.0f;
    juce::Rectangle<int> brandTextHitbox;

    // panel bounds are computed once in resized() and reused by paint()
    juce::Rectangle<int> headerBounds, inputPanelBounds, limiterPanelBounds, spectralPanelBounds, outputPanelBounds, statusBounds, settingsBoxBounds, visualizerBounds;

    juce::Colour bgColour, accentColour, textColour, panelFillColour, subTextColour;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (PluginCanvas)
};

//==============================================================================
// The actual host-facing editor: a thin wrapper that's free to be any size the
// host/user drags it to, holding a PluginCanvas fixed at its native size and
// rescaling that canvas as a single unit (via a transform) to fill whatever
// space is available. Everything -- chrome, panels, knobs, text -- scales
// together this way, rather than just the margin around a fixed-size UI.
//==============================================================================
class SpectralLimiterAudioProcessorEditor  : public juce::AudioProcessorEditor
{
public:
    SpectralLimiterAudioProcessorEditor (SpectralLimiterAudioProcessor&);
    ~SpectralLimiterAudioProcessorEditor() override = default;

    void paint (juce::Graphics&) override;
    void resized() override;

private:
    SpectralLimiterAudioProcessor& audioProcessor;
    PluginCanvas canvas;

    // default size the window returns to on a double-click of the corner handle
    static constexpr int defaultWidth = PluginCanvas::nativeWidth, defaultHeight = PluginCanvas::nativeHeight;
    juce::ComponentBoundsConstrainer sizeConstrainer;
    std::unique_ptr<juce::Component> cornerResizer;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (SpectralLimiterAudioProcessorEditor)
};
