#include "PluginProcessor.h"
#include "PluginEditor.h"

SpectralLimiterAudioProcessor::SpectralLimiterAudioProcessor()
     : AudioProcessor (BusesProperties()
                       .withInput  ("Input",  juce::AudioChannelSet::stereo(), true)
                       .withOutput ("Output", juce::AudioChannelSet::stereo(), true)
                       ),
       apvts (*this, nullptr, "Parameters", createParameterLayout())
{
}

SpectralLimiterAudioProcessor::~SpectralLimiterAudioProcessor() {}

juce::AudioProcessorValueTreeState::ParameterLayout SpectralLimiterAudioProcessor::createParameterLayout()
{
    std::vector<std::unique_ptr<juce::RangedAudioParameter>> params;

    params.push_back (std::make_unique<juce::AudioParameterFloat> (juce::ParameterID ("GAIN", 1), "Input Gain", 0.0f, 24.0f, 0.0f));
    params.push_back (std::make_unique<juce::AudioParameterFloat> (juce::ParameterID ("CEILING", 1), "Ceiling", -12.0f, 0.0f, -0.1f));
    params.push_back (std::make_unique<juce::AudioParameterFloat> (juce::ParameterID ("RELEASE", 1), "Release Time", 1.0f, 500.0f, 20.0f));
    params.push_back (std::make_unique<juce::AudioParameterFloat> (juce::ParameterID ("BASS_ELAST", 1), "Bass Elasticity", 0.0f, 1.0f, 0.0f));
    params.push_back (std::make_unique<juce::AudioParameterFloat> (juce::ParameterID ("CEIL_TOPO", 1), "Ceiling Topology", 0.0f, 3.0f, 0.0f));
    params.push_back (std::make_unique<juce::AudioParameterFloat> (juce::ParameterID ("PRE_SAT", 1), "Pre-Saturation", 0.0f, 1.0f, 0.0f));
    params.push_back (std::make_unique<juce::AudioParameterFloat> (juce::ParameterID ("SC_UNLINK", 1), "Stereo Unlink", 0.0f, 100.0f, 0.0f));
    params.push_back (std::make_unique<juce::AudioParameterFloat> (juce::ParameterID ("FREQ_MIN", 1), "Spectral Cutoff Min", 20.0f, 2000.0f, 200.0f));
    params.push_back (std::make_unique<juce::AudioParameterFloat> (juce::ParameterID ("FREQ_MAX", 1), "Spectral Cutoff Max", 2000.0f, 20000.0f, 8000.0f));

    params.push_back (std::make_unique<juce::AudioParameterBool> (juce::ParameterID ("DELTA", 1), "Delta Audition", false));
    params.push_back (std::make_unique<juce::AudioParameterBool> (juce::ParameterID ("SPECTRAL_ON", 1), "Spectral Tracking Engine", false));
    params.push_back (std::make_unique<juce::AudioParameterBool> (juce::ParameterID ("IS_LIGHT_THEME", 1), "Light Theme Mode", false));
    
    params.push_back (std::make_unique<juce::AudioParameterFloat> (juce::ParameterID ("MIX", 1), "Mix", 0.0f, 100.0f, 100.0f));

    // Final-stage output dither -- this plugin is intended to sit last on a master
    // chain, so a proper dither ahead of any downstream bit-depth reduction (e.g.
    // export to a 16-bit delivery master) is a genuinely useful, not cosmetic,
    // addition. See SpectralLimiterAudioProcessor::applyDither().
    params.push_back (std::make_unique<juce::AudioParameterChoice> (juce::ParameterID ("DITHER_MODE", 1), "Dither Mode",
        juce::StringArray { "Off", "16-Bit Dither", "24-Bit Dither", "Shaped Noise Dither" }, 0));

    return { params.begin(), params.end() };
}

const juce::String SpectralLimiterAudioProcessor::getName() const { return JucePlugin_Name; }
bool SpectralLimiterAudioProcessor::acceptsMidi() const { return false; }
bool SpectralLimiterAudioProcessor::producesMidi() const { return false; }
bool SpectralLimiterAudioProcessor::isMidiEffect() const { return false; }
double SpectralLimiterAudioProcessor::getTailLengthSeconds() const { return 0.0; }
int SpectralLimiterAudioProcessor::getNumPrograms() { return 1; }
int SpectralLimiterAudioProcessor::getCurrentProgram() { return 0; }
void SpectralLimiterAudioProcessor::setCurrentProgram (int index) {}
const juce::String SpectralLimiterAudioProcessor::getProgramName (int index) { return {}; }
void SpectralLimiterAudioProcessor::changeProgramName (int index, const juce::String& newName) {}

bool SpectralLimiterAudioProcessor::isBusesLayoutSupported (const BusesLayout& layouts) const
{
    if (layouts.getMainOutputChannelSet() != layouts.getMainInputChannelSet())
        return false;
    if (layouts.getMainInputChannelSet() != juce::AudioChannelSet::stereo())
        return false;
    return true;
}

void SpectralLimiterAudioProcessor::prepareToPlay (double sampleRate, int samplesPerBlock)
{
    currentSampleRate = sampleRate;

    juce::dsp::ProcessSpec spec;
    spec.sampleRate = sampleRate;
    spec.maximumBlockSize = juce::uint32 (samplesPerBlock);
    spec.numChannels = 2;

    lowPassFilterL.reset();  lowPassFilterR.reset();
    highPassFilterL.reset(); highPassFilterR.reset();

    lowPassFilterL.prepare (spec);  lowPassFilterR.prepare (spec);
    highPassFilterL.prepare (spec); highPassFilterR.prepare (spec);

    lowPassFilterL.setType (juce::dsp::StateVariableTPTFilterType::lowpass);
    lowPassFilterR.setType (juce::dsp::StateVariableTPTFilterType::lowpass);
    highPassFilterL.setType (juce::dsp::StateVariableTPTFilterType::highpass);
    highPassFilterR.setType (juce::dsp::StateVariableTPTFilterType::highpass);

    lookAheadSamples = int (0.002 * sampleRate);
    lookAheadBuffer.setSize (2, lookAheadSamples + samplesPerBlock + 4);
    lookAheadBuffer.clear();
    writeIndex = 0;

    envLeft = 0.0f;
    envRight = 0.0f;
    lastGainReduction.set (0.0f);

    std::fill (fftFifo.begin(), fftFifo.end(), 0.0f);
    std::fill (fftBuffer.begin(), fftBuffer.end(), 0.0f);
    std::fill (fftGetData.begin(), fftGetData.end(), 0.0f);
    fftFifoIndex = 0;
    fftDataReady.set (false);

    noiseShapeErrorL = 0.0f;
    noiseShapeErrorR = 0.0f;
}

void SpectralLimiterAudioProcessor::releaseResources() {}

void SpectralLimiterAudioProcessor::processBlock (juce::AudioBuffer<float>& buffer, juce::MidiBuffer& midiMessages)
{
    juce::ScopedNoDenormals noDenormals;
    
    auto totalNumInputChannels  = getTotalNumInputChannels();
    auto totalNumOutputChannels = getTotalNumOutputChannels();

    for (auto i = totalNumInputChannels; i < totalNumOutputChannels; ++i)
        buffer.clear (i, 0, buffer.getNumSamples());

    int numSamples = buffer.getNumSamples();
    if (numSamples == 0) return;

    float gainDB = apvts.getRawParameterValue ("GAIN")->load();
    float ceilingDB = apvts.getRawParameterValue ("CEILING")->load();
    float releaseMs = apvts.getRawParameterValue ("RELEASE")->load();
    float bassElasticity = apvts.getRawParameterValue ("BASS_ELAST")->load();
    float topology = apvts.getRawParameterValue ("CEIL_TOPO")->load();
    float preSat = apvts.getRawParameterValue ("PRE_SAT")->load();
    float scUnlink = apvts.getRawParameterValue ("SC_UNLINK")->load();
    float freqMin = apvts.getRawParameterValue ("FREQ_MIN")->load();
    float freqMax = apvts.getRawParameterValue ("FREQ_MAX")->load();
    bool deltaAudition = apvts.getRawParameterValue ("DELTA")->load() > 0.5f;
    bool spectralOn = apvts.getRawParameterValue ("SPECTRAL_ON")->load() > 0.5f;
    float mixParam = apvts.getRawParameterValue ("MIX")->load() / 100.0f;
    int ditherMode = (int) apvts.getRawParameterValue ("DITHER_MODE")->load();

    float inputGain = juce::Decibels::decibelsToGain (gainDB);
    float ceiling = juce::Decibels::decibelsToGain (ceilingDB);

    float baseReleaseTime = releaseMs / 1000.0f;

    lowPassFilterL.setCutoffFrequency (freqMax);
    lowPassFilterR.setCutoffFrequency (freqMax);
    highPassFilterL.setCutoffFrequency (freqMin);
    highPassFilterR.setCutoffFrequency (freqMin);

    float maxGRThisBlock = 0.0f;

    auto safeSign = [](float val) -> float { return (val > 0.0f) ? 1.0f : ((val < 0.0f) ? -1.0f : 0.0f); };

    for (int sample = 0; sample < numSamples; ++sample)
    {
        float rawL = buffer.getSample (0, sample) * inputGain;
        float rawR = buffer.getSample (1, sample) * inputGain;

        if (preSat > 0.01f)
        {
            float satDrive = 1.0f + (preSat * 1.5f);
            rawL = std::tanh (rawL * satDrive) / satDrive;
            rawR = std::tanh (rawR * satDrive) / satDrive;
        }

        lookAheadBuffer.setSample (0, (writeIndex + sample) % lookAheadBuffer.getNumSamples(), rawL);
        lookAheadBuffer.setSample (1, (writeIndex + sample) % lookAheadBuffer.getNumSamples(), rawR);

        int readIndex = (writeIndex + sample - lookAheadSamples + lookAheadBuffer.getNumSamples()) % lookAheadBuffer.getNumSamples();
        float delayedL = lookAheadBuffer.getSample (0, readIndex);
        float delayedR = lookAheadBuffer.getSample (1, readIndex);

        float sidechainL = rawL;
        float sidechainR = rawR;

        if (spectralOn)
        {
            float lFiltered = highPassFilterL.processSample (0, sidechainL);
            lFiltered = lowPassFilterL.processSample (0, lFiltered);
            float rFiltered = highPassFilterR.processSample (1, sidechainR);
            rFiltered = lowPassFilterR.processSample (1, rFiltered);

            sidechainL = juce::jmap (0.75f, sidechainL, lFiltered);
            sidechainR = juce::jmap (0.75f, sidechainR, rFiltered);
        }

        float absL = std::abs (sidechainL);
        float absR = std::abs (sidechainR);

        if (scUnlink > 0.0f)
        {
            float maxVal = juce::jmax (absL, absR);
            float linkedVal = maxVal;
            float unlinkFactor = scUnlink / 100.0f;
            absL = juce::jmap (unlinkFactor, absL, linkedVal);
            absR = juce::jmap (unlinkFactor, absR, linkedVal);
        }
        else
        {
            float maxVal = juce::jmax (absL, absR);
            absL = maxVal;
            absR = maxVal;
        }

        float dynamicReleaseL = baseReleaseTime;
        float dynamicReleaseR = baseReleaseTime;

        if (bassElasticity > 0.01f)
        {
            float lowFreqEstL = absL - lowPassFilterL.processSample (0, rawL);
            float lowFreqEstR = absR - lowPassFilterR.processSample (1, rawR);
            dynamicReleaseL += std::abs (lowFreqEstL) * 0.3f * bassElasticity;
            dynamicReleaseR += std::abs (lowFreqEstR) * 0.3f * bassElasticity;
        }

        // Near-instant attack: correct for a lookahead brickwall limiter, and the
        // envelope follower needs a nonzero attack coefficient to ever respond to
        // rising signal level in the first place -- 0.0 here previously locked the
        // envelope at its initial value forever, so the limiter never engaged.
        float alphaAttack = 1.0f;
        float alphaReleaseL = float (1.0 - std::exp (-1.0 / (dynamicReleaseL * currentSampleRate)));
        float alphaReleaseR = float (1.0 - std::exp (-1.0 / (dynamicReleaseR * currentSampleRate)));

        if (absL > envLeft) envLeft += alphaAttack * (absL - envLeft);
        else                envLeft += alphaReleaseL * (absL - envLeft);

        if (absR > envRight) envRight += alphaAttack * (absR - envRight);
        else                 envRight += alphaReleaseR * (absR - envRight);

        float softKneeFactor = 1.0f;
        if (topology > 0.01f)
        {
            softKneeFactor = 1.0f - (topology * 0.15f);
        }

        float targetGainL = 1.0f;
        if (envLeft > (ceiling * softKneeFactor) && envLeft > 0.0f)
            targetGainL = (ceiling * softKneeFactor) / envLeft;

        float targetGainR = 1.0f;
        if (envRight > (ceiling * softKneeFactor) && envRight > 0.0f)
            targetGainR = (ceiling * softKneeFactor) / envRight;

        float outL = delayedL * targetGainL;
        float outR = delayedR * targetGainR;

        if (std::abs (outL) > ceiling) outL = safeSign (outL) * ceiling;
        if (std::abs (outR) > ceiling) outR = safeSign (outR) * ceiling;

        float grL = 1.0f - targetGainL;
        float grR = 1.0f - targetGainR;
        float maxGRThisSample = juce::jmax (grL, grR);
        if (maxGRThisSample > maxGRThisBlock)
            maxGRThisBlock = maxGRThisSample;

        float monoVisualizerSignal = (delayedL + delayedR) * 0.5f;
        fftFifo[size_t (fftFifoIndex)] = monoVisualizerSignal;
        if (++fftFifoIndex >= fftSize)
        {
            if (! fftDataReady.get())
            {
                std::fill (fftBuffer.begin(), fftBuffer.end(), 0.0f);
                std::copy (fftFifo.begin(), fftFifo.end(), fftBuffer.begin());
                window.multiplyWithWindowingTable (fftBuffer.data(), fftSize);
                forwardFFT.performFrequencyOnlyForwardTransform (fftBuffer.data());
                std::copy (fftBuffer.begin(), fftBuffer.begin() + (fftSize / 2), fftGetData.begin());
                fftDataReady.set (true);
            }
            fftFifoIndex = 0;
        }

        float finalL, finalR;

        // The dry reference for the Mix blend has to be time-aligned with the
        // wet signal, or blending them is effectively summing two copies of the
        // same signal offset by lookAheadSamples (~2ms) -- a comb filter, heard
        // as flanging, that gets worse the further Mix sits from fully wet/dry.
        // rawL/rawR are *this* sample, undelayed; delayedL/delayedR (already
        // read back from the lookahead buffer above) are the same signal
        // lookAheadSamples in the past -- exactly what outL/outR/wetL/wetR were
        // themselves derived from. Using the delayed version as "dry" instead
        // of the instantaneous one costs nothing extra (the buffer read already
        // happened) and makes dry and wet phase-aligned at every Mix setting.
        float dryL = delayedL / inputGain;
        float dryR = delayedR / inputGain;

        if (deltaAudition)
        {
            float wetL = delayedL - outL;
            float wetR = delayedR - outR;
            finalL = juce::jmap (mixParam, dryL, wetL);
            finalR = juce::jmap (mixParam, dryR, wetR);
        }
        else
        {
            finalL = juce::jmap (mixParam, dryL, outL);
            finalR = juce::jmap (mixParam, dryR, outR);
        }

        // Dither is applied last, right before the sample leaves the plugin --
        // it has to be the very last thing touching the signal, or any later
        // processing (including this plugin's own smoothing) would just undo it.
        if (ditherMode != 0)
        {
            finalL = applyDither (finalL, noiseShapeErrorL, ditherMode);
            finalR = applyDither (finalR, noiseShapeErrorR, ditherMode);
        }

        buffer.setSample (0, sample, finalL);
        buffer.setSample (1, sample, finalR);
    }

    writeIndex = (writeIndex + numSamples) % lookAheadBuffer.getNumSamples();
    lastGainReduction.set (maxGRThisBlock);
}

float SpectralLimiterAudioProcessor::applyDither (float sample, float& shapeError, int ditherMode) noexcept
{
    // LSB size for the target bit depth, in a normalised -1..1 float signal:
    // a 16-bit word covers 65536 steps across the full-scale range (2.0), a
    // 24-bit word covers 16777216 steps. "Shaped Noise Dither" targets 16-bit,
    // the common final delivery depth this plugin (last on the master chain)
    // is most likely dithering ahead of.
    const float lsb16 = 1.0f / 32768.0f;
    const float lsb24 = 1.0f / 8388608.0f;
    const float lsb = (ditherMode == 2) ? lsb24 : lsb16;

    // TPDF (triangular-PDF) dither: the sum of two independent uniform random
    // variables. Unlike a single uniform (rectangular-PDF) source, TPDF dither
    // fully decorrelates the quantization error from the signal with no residual
    // signal-dependent distortion, which is why it's the standard choice for
    // audio dither rather than a single random offset.
    float tpdf = ((ditherRandom.nextFloat() - 0.5f) + (ditherRandom.nextFloat() - 0.5f)) * lsb;

    if (ditherMode == 3)
    {
        // Shaped Noise Dither: a simple 1st-order noise-shaping feedback loop.
        // The quantization error from the previous sample is fed back (negated)
        // into this one before dithering and quantizing again -- this pushes the
        // resulting noise floor up in frequency, away from the ear's most
        // sensitive range, rather than leaving it flat like plain TPDF dither.
        float shapedInput = sample - shapeError + tpdf;
        float quantized = std::round (shapedInput / lsb16) * lsb16;
        shapeError = quantized - sample;
        return quantized;
    }

    // Off never reaches here (guarded by the caller); modes 1 and 2 are plain
    // TPDF dither at 16-bit and 24-bit respectively, with no error feedback.
    return sample + tpdf;
}

bool SpectralLimiterAudioProcessor::hasEditor() const { return true; }
juce::AudioProcessorEditor* SpectralLimiterAudioProcessor::createEditor() { return new SpectralLimiterAudioProcessorEditor (*this); }

void SpectralLimiterAudioProcessor::getStateInformation(juce::MemoryBlock& destData)
{
    auto state = apvts.copyState();

    state.setProperty("presetName", currentPresetName, nullptr);

    std::unique_ptr<juce::XmlElement> xml(state.createXml());

    if (xml != nullptr)
        copyXmlToBinary(*xml, destData);
}


void SpectralLimiterAudioProcessor::setStateInformation(const void* data, int sizeInBytes)
{
    std::unique_ptr<juce::XmlElement> xmlState(getXmlFromBinary(data, sizeInBytes));
    if (xmlState != nullptr)
    {
        if (xmlState->hasTagName(apvts.state.getType()))
        {
            auto state = juce::ValueTree::fromXml(*xmlState);
            if (state.isValid())
            {
                apvts.replaceState(state);
                currentPresetName = state.getProperty("presetName", "INIT").toString();
            }
        }
    }
}



juce::AudioProcessor* JUCE_CALLTYPE createPluginFilter() { return new SpectralLimiterAudioProcessor(); }
