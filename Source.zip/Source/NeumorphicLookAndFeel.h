#pragma once

#include <JuceHeader.h>
#include <melatonin_blur/melatonin_blur.h>

//==============================================================================
// A soft-UI ("neumorphic") LookAndFeel: every surface is filled with the same
// flat base colour as the panel it sits on, and depth comes entirely from a
// pair of stacked shadows (a light one to the top-left, a dark one to the
// bottom-right) rather than from gradients, borders, or contrasting fills.
// Pressed / toggled-on controls swap to a pair of inner shadows so they read
// as carved into the surface instead of sitting on top of it.
//
// Uses the exact palette already established by SkeuoLookAndFeel elsewhere in
// this plugin:
//   dark mode  -> background 0xFF0A0A0E, panel/base 0xFF121216, ink white
//   light mode -> background 0xFFD9D4C8, panel/base 0xFFE7E2D5, ink 0xFF0A0A0E
//==============================================================================
class NeumorphicLookAndFeel : public juce::LookAndFeel_V4
{
public:
    NeumorphicLookAndFeel();

    // Call whenever the plugin's theme toggle or accent-colour picker changes,
    // same as customLAF.setLightMode()/setAccentColor() elsewhere in the editor.
    void setDarkMode (bool shouldBeDark)      { isDarkMode = shouldBeDark; }
    void setAccentColor (juce::Colour colour) { accentColour = colour; }

    void drawRotarySlider (juce::Graphics&, int x, int y, int width, int height,
                            float sliderPos, float startAngle, float endAngle, juce::Slider&) override;

    void drawLinearSlider (juce::Graphics&, int x, int y, int width, int height,
                            float sliderPos, float minSliderPos, float maxSliderPos,
                            juce::Slider::SliderStyle, juce::Slider&) override;

    void drawToggleButton (juce::Graphics&, juce::ToggleButton&, bool isHighlighted, bool isDown) override;

    void drawButtonBackground (juce::Graphics&, juce::Button&, const juce::Colour& backgroundColour,
                                bool isHighlighted, bool isDown) override;

    void drawComboBox (juce::Graphics&, int width, int height, bool isButtonDown,
                        int buttonX, int buttonY, int buttonW, int buttonH, juce::ComboBox&) override;
    void positionComboBoxText (juce::ComboBox&, juce::Label&) override;

    void drawPopupMenuBackground (juce::Graphics&, int width, int height) override;
    void drawPopupMenuItem (juce::Graphics&, const juce::Rectangle<int>& area, bool isSeparator, bool isActive,
                             bool isHighlighted, bool isTicked, bool hasSubMenu, const juce::String& text,
                             const juce::String& shortcutKeyText, const juce::Drawable* icon,
                             const juce::Colour* textColour) override;

    void drawLabel (juce::Graphics&, juce::Label&) override;

private:
    juce::Colour getBaseColour() const;
    juce::Colour getTextColour() const;

    bool isDarkMode = true;
    juce::Colour accentColour { juce::Colours::white };

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (NeumorphicLookAndFeel)
};
