#include "NeumorphicLookAndFeel.h"

//==============================================================================
NeumorphicLookAndFeel::NeumorphicLookAndFeel()
{
    setColour (juce::Slider::rotarySliderFillColourId, juce::Colours::white);
    setColour (juce::Slider::rotarySliderOutlineColourId, juce::Colours::transparentBlack);
    setColour (juce::Slider::textBoxTextColourId, juce::Colours::white);
    setColour (juce::Slider::textBoxOutlineColourId, juce::Colours::transparentBlack);
    setColour (juce::TextButton::textColourOffId, juce::Colours::white);
    setColour (juce::TextButton::textColourOnId, juce::Colours::white);
}

juce::Colour NeumorphicLookAndFeel::getBaseColour() const
{
    // identical to bgColour/panelFillColour used elsewhere in the plugin --
    // this is what makes the neumorphic effect read correctly: the control
    // and the panel behind it must be exactly the same flat colour.
    return isDarkMode ? juce::Colour (0xFF121216) : juce::Colour (0xFFE7E2D5);
}

juce::Colour NeumorphicLookAndFeel::getTextColour() const
{
    return isDarkMode ? juce::Colours::white : juce::Colour (0xFF0A0A0E);
}

//==============================================================================
void NeumorphicLookAndFeel::drawRotarySlider (juce::Graphics& g, int x, int y, int width, int height,
                                               float sliderPos, float startAngle, float endAngle,
                                               juce::Slider& slider)
{
    // Margin must comfortably exceed the shadow's reach (blur + offset) below,
    // or JUCE's per-component clip region cuts the shadow off flat against the
    // slider's own bounds -- this was clipping every knob's extruded edge.
    auto bounds   = juce::Rectangle<int> (x, y, width, height).toFloat().reduced (12.0f);
    auto diameter = juce::jmin (bounds.getWidth(), bounds.getHeight());
    auto radius   = diameter * 0.5f;
    // Anchored to the bottom of the available area rather than vertically
    // centred: when the area is taller than it is wide (narrower knobs, like
    // the side-by-side FREQ_MIN/FREQ_MAX pair), centring left empty space both
    // above and below the circle, pushing it further from its number readout
    // than knobs with more-square bounds. Anchoring to the bottom closes that
    // gap; it's a no-op whenever height was already the limiting dimension
    // (the two are mathematically identical in that case).
    auto centre   = juce::Point<float> (bounds.getCentreX(), bounds.getBottom() - radius);
    juce::Rectangle<float> knobBounds (centre.x - radius, centre.y - radius, diameter, diameter);

    juce::Path knobPath;
    knobPath.addEllipse (knobBounds);

    auto base = getBaseColour();

    // ---- extruded disc: two stacked drop shadows behind a flat fill ----
    // Dark mode needs much lower shadow alpha than light mode -- a "white
    // highlight" at light-mode strength would blow out completely against a
    // near-black base, and a "dark shadow" at light-mode strength would just
    // look like a black ring rather than a subtle depth cue. Reach (blur +
    // offset) is 8px here, safely inside the 12px margin above.
    melatonin::DropShadow highlight = {{ juce::Colours::white.withAlpha (isDarkMode ? 0.05f : 0.85f), 6, { -2, -2 } }};
    melatonin::DropShadow shadow    = {{ juce::Colours::black.withAlpha (isDarkMode ? 0.55f : 0.25f), 6, { 2, 2 } }};
    highlight.render (g, knobPath);
    shadow.render (g, knobPath);

    g.setColour (base);
    g.fillPath (knobPath);

    // ---- recessed groove carved into the disc face, as a value track ----
    auto trackBounds = knobBounds.reduced (radius * 0.18f);
    juce::Path trackPath;
    trackPath.addEllipse (trackBounds);

    g.setColour (base);
    g.fillPath (trackPath);

    melatonin::InnerShadow trackShadow    = {{ juce::Colours::black.withAlpha (isDarkMode ? 0.6f : 0.35f), 5, { 2, 2 } }};
    melatonin::InnerShadow trackHighlight = {{ juce::Colours::white.withAlpha (isDarkMode ? 0.04f : 0.65f), 5, { -2, -2 } }};
    trackShadow.render (g, trackPath);
    trackHighlight.render (g, trackPath);

    // ---- value arc + pointer, in the accent colour so the control stays legible ----
    auto angle      = startAngle + sliderPos * (endAngle - startAngle);
    float arcRadius = radius - radius * 0.32f;

    juce::Path fullTrack;
    fullTrack.addCentredArc (centre.x, centre.y, arcRadius, arcRadius, 0.0f, startAngle, endAngle, true);
    g.setColour (getTextColour().withAlpha (0.08f));
    g.strokePath (fullTrack, juce::PathStrokeType (3.0f, juce::PathStrokeType::JointStyle::curved,
                                                    juce::PathStrokeType::EndCapStyle::rounded));

    juce::Path valueArc;
    valueArc.addCentredArc (centre.x, centre.y, arcRadius, arcRadius, 0.0f, startAngle, angle, true);
    g.setColour (accentColour);
    g.strokePath (valueArc, juce::PathStrokeType (3.0f, juce::PathStrokeType::JointStyle::curved,
                                                   juce::PathStrokeType::EndCapStyle::rounded));

    auto tipOuter = centre.getPointOnCircumference (radius * 0.62f, angle);
    auto tipInner = centre.getPointOnCircumference (radius * 0.24f, angle);
    g.setColour (accentColour);
    g.drawLine (tipInner.x, tipInner.y, tipOuter.x, tipOuter.y, 2.5f);
}

//==============================================================================
void NeumorphicLookAndFeel::drawButtonBackground (juce::Graphics& g, juce::Button& button,
                                                   const juce::Colour& /*backgroundColour*/,
                                                   bool isHighlighted, bool isDown)
{
    // Opt-out for buttons that are really just a clickable image (e.g. the brand
    // logo) -- no pill, no shadow, nothing painted here at all. The image itself
    // is drawn separately, on top, by the caller.
    if (button.getProperties().contains ("noChrome"))
        return;

    // A hidden easter egg: only the faintest hint of a shadow, deliberately
    // subtle enough to blend into the panel it sits on -- no fill, no outline,
    // nothing that would give away there's a button here.
    if (button.getProperties().contains ("easterEgg"))
    {
        auto eggBounds = button.getLocalBounds().toFloat().reduced (3.0f);
        juce::Path eggShape;
        eggShape.addRoundedRectangle (eggBounds, juce::jmin (eggBounds.getWidth(), eggBounds.getHeight()) * 0.28f);

        melatonin::DropShadow whisper = {{ juce::Colours::black.withAlpha (isDarkMode ? 0.07f : 0.035f), 4, { 1, 1 } }};
        whisper.render (g, eggShape);
        return;
    }

    // A small, fixed inset -- enough for the (now deliberately tight) drop shadow
    // below to render cleanly on even the smallest buttons, without eating so much
    // of a big button's height that its fill looks thin under its own label.
    auto bounds = button.getLocalBounds().toFloat().reduced (3.0f);
    float corner = juce::jmin (bounds.getWidth(), bounds.getHeight()) * 0.28f;

    juce::Path shape;
    shape.addRoundedRectangle (bounds, corner);

    auto base = getBaseColour();
    bool pressed = isDown || button.getToggleState();

    g.setColour (base);
    g.fillPath (shape);

    if (! pressed)
    {
        // resting state -- pops out of the panel
        melatonin::DropShadow highlight = {{ juce::Colours::white.withAlpha (isDarkMode ? 0.05f : 0.85f), 4, { -2, -2 } }};
        melatonin::DropShadow shadow    = {{ juce::Colours::black.withAlpha (isDarkMode ? 0.55f : 0.25f), 4, { 2, 2 } }};
        highlight.render (g, shape);
        shadow.render (g, shape);

        g.setColour (base);
        g.fillPath (shape);
    }
    else
    {
        // pressed / toggled-on state -- sinks into the panel
        melatonin::InnerShadow innerShadow    = {{ juce::Colours::black.withAlpha (isDarkMode ? 0.6f : 0.35f), 6, { 3, 3 } }};
        melatonin::InnerShadow innerHighlight = {{ juce::Colours::white.withAlpha (isDarkMode ? 0.04f : 0.65f), 6, { -3, -3 } }};
        innerShadow.render (g, shape);
        innerHighlight.render (g, shape);
    }

    if (pressed)
    {
        g.setColour (accentColour.withAlpha (0.9f));
        g.strokePath (shape, juce::PathStrokeType (1.5f));
    }
    else if (isHighlighted)
    {
        g.setColour (accentColour.withAlpha (0.35f));
        g.strokePath (shape, juce::PathStrokeType (1.2f));
    }
}

//==============================================================================
// Horizontal fader (topology strip, stereo-unlink slider): a sunken channel with
// an accent-coloured fill clipped inside it, and a small raised thumb riding on
// top -- the linear equivalent of the rotary knob's carved groove + extruded cap.
void NeumorphicLookAndFeel::drawLinearSlider (juce::Graphics& g, int x, int y, int width, int height,
                                               float sliderPos, float /*minSliderPos*/, float /*maxSliderPos*/,
                                               juce::Slider::SliderStyle style, juce::Slider& slider)
{
    if (style != juce::Slider::SliderStyle::LinearHorizontal)
    {
        LookAndFeel_V4::drawLinearSlider (g, x, y, width, height, sliderPos, 0.0f, 0.0f, style, slider);
        return;
    }

    auto ink  = getTextColour();
    auto base = getBaseColour();

    float trackH = 8.0f;
    float trackY = (float) y + (float) height * 0.5f - trackH * 0.5f;
    juce::Rectangle<float> track ((float) x, trackY, (float) width, trackH);
    juce::Path trackPath;
    trackPath.addRoundedRectangle (track, trackH * 0.5f);

    g.setColour (base);
    g.fillPath (trackPath);

    melatonin::InnerShadow trackDark  = {{ juce::Colours::black.withAlpha (isDarkMode ? 0.55f : 0.30f), 5, { 2, 2 } }};
    melatonin::InnerShadow trackLight = {{ juce::Colours::white.withAlpha (isDarkMode ? 0.04f : 0.6f), 5, { -2, -2 } }};
    trackDark.render (g, trackPath);
    trackLight.render (g, trackPath);

    // filled portion, clipped to the sunken channel so it reads as "liquid in a
    // groove" rather than a bar floating on top of it
    if (sliderPos > (float) x + 1.0f)
    {
        juce::Graphics::ScopedSaveState save (g);
        g.reduceClipRegion (trackPath);
        g.setColour (accentColour.withAlpha (isDarkMode ? 0.55f : 0.65f));
        g.fillRect (juce::Rectangle<float> ((float) x, trackY, sliderPos - (float) x, trackH));
    }

    // Small, quiet anchor dots marking exactly where a magnetic slider (see
    // MagneticTopologySlider) will pull toward -- opt-in via a "magnetAnchors"
    // component property (the count of evenly-spaced anchors across the
    // slider's range), so ordinary linear sliders like stereo-unlink are
    // unaffected. Drawn after the fill and before the thumb, so the thumb
    // naturally covers whichever anchor it's currently sitting on.
    if (slider.getProperties().contains ("magnetAnchors"))
    {
        int numAnchors = (int) slider.getProperties()["magnetAnchors"];
        if (numAnchors > 1)
        {
            float dotR = 2.0f;
            g.setColour (ink.withAlpha (0.28f));
            for (int i = 0; i < numAnchors; ++i)
            {
                float t = (float) i / (float) (numAnchors - 1);
                // Inset by the dot's own radius so the first and last dots sit
                // fully inside the track instead of straddling its edge -- at
                // t=0/t=1 the un-inset version centred the dot exactly on the
                // track boundary, leaving half of it outside the visible groove.
                float dotX = (float) x + dotR + t * ((float) width - 2.0f * dotR);
                g.fillEllipse (dotX - dotR, trackY + trackH * 0.5f - dotR, dotR * 2.0f, dotR * 2.0f);
            }
        }
    }

    // Thumb diameter is capped well below (height - 12) so the shadow's 4px
    // reach always fits inside the vertical margin -- at height=28 (the topology
    // strip) the old 20px thumb only left a 4px margin for a 7px-reach shadow,
    // clipping it flat top and bottom.
    float thumbD = juce::jmin (16.0f, (float) height - 12.0f);
    juce::Rectangle<float> thumb (sliderPos - thumbD * 0.5f, (float) y + (float) height * 0.5f - thumbD * 0.5f, thumbD, thumbD);
    juce::Path thumbPath;
    thumbPath.addEllipse (thumb);

    melatonin::DropShadow thumbHi = {{ juce::Colours::white.withAlpha (isDarkMode ? 0.06f : 0.85f), 3, { -1, -1 } }};
    melatonin::DropShadow thumbSh = {{ juce::Colours::black.withAlpha (isDarkMode ? 0.55f : 0.25f), 3, { 1, 1 } }};
    thumbHi.render (g, thumbPath);
    thumbSh.render (g, thumbPath);

    g.setColour (base);
    g.fillPath (thumbPath);
    g.setColour (ink.withAlpha (0.16f));
    g.drawEllipse (thumb, 1.0f);
    g.setColour (accentColour);
    g.fillEllipse (thumb.reduced (thumbD * 0.32f));
}

//==============================================================================
// Every ToggleButton in the plugin (engine on/off switches, meter/analyzer
// ballistics radios, the theme + tooltips checkboxes) shares this one switch
// design: a sunken track, a raised thumb that slides to the "on" side, and --
// when engaged -- a genuine melatonin-blurred halo behind the thumb so
// "enabled" states like the spectral-tracking switch read as properly glowing
// rather than just a colour change. The halo radius is capped tightly and the
// label text is trimmed well clear of it, so the glow never creeps onto
// neighbouring text or controls.
void NeumorphicLookAndFeel::drawToggleButton (juce::Graphics& g, juce::ToggleButton& button,
                                               bool isHighlighted, bool /*isDown*/)
{
    bool on = button.getToggleState();
    auto ink  = getTextColour();
    auto base = getBaseColour();

    // Sized so the halo below always has enough vertical margin to fully render
    // even on the shortest toggle buttons (26px tall, e.g. the theme/tooltips
    // checkboxes): a 16px thumb left only 5px of margin for a 19px-reach halo,
    // hard-clipping it flat against the button's top and bottom edges. A 10px
    // thumb leaves 8px of margin, comfortably inside the 7px reach below.
    const float trackW = 20.0f, trackH = 9.0f, trackX = 4.0f;
    const float thumbD = 10.0f;
    const float textLeftInset = 36.0f; // fixed: clear of the track/thumb/halo in every state

    juce::Rectangle<float> track (trackX, (float) button.getHeight() * 0.5f - trackH * 0.5f, trackW, trackH);
    juce::Path trackPath;
    trackPath.addRoundedRectangle (track, trackH * 0.5f);

    g.setColour (base);
    g.fillPath (trackPath);

    melatonin::InnerShadow trackDark  = {{ juce::Colours::black.withAlpha (isDarkMode ? 0.6f : 0.30f), 3, { 1, 1 } }};
    melatonin::InnerShadow trackLight = {{ juce::Colours::white.withAlpha (isDarkMode ? 0.04f : 0.6f), 3, { -1, -1 } }};
    trackDark.render (g, trackPath);
    trackLight.render (g, trackPath);

    if (on)
    {
        g.setColour (accentColour.withAlpha (isDarkMode ? 0.22f : 0.30f));
        g.fillPath (trackPath);
    }

    float thumbX = on ? track.getRight() - thumbD + 1.0f : track.getX() - 1.0f;
    juce::Point<float> thumbC (thumbX + thumbD * 0.5f, track.getCentreY());
    juce::Rectangle<float> thumbBounds (thumbC.x - thumbD * 0.5f, thumbC.y - thumbD * 0.5f, thumbD, thumbD);
    juce::Path thumbPath;
    thumbPath.addEllipse (thumbBounds);

    if (on)
    {
        // Halo base shape still has to stay a little larger than the thumb
        // (radius 5) or its own opaque fill hides it -- but both the radius and
        // the alpha are pulled well back from the last pass so this reads as a
        // gentle glow rather than a hot LED.
        auto glowColour = accentColour;
        float haloR = 6.0f;
        juce::Path halo;
        halo.addEllipse (thumbC.x - haloR, thumbC.y - haloR, haloR * 2.0f, haloR * 2.0f);

        melatonin::DropShadow glowBloom = {{ glowColour.withAlpha (isDarkMode ? 0.30f : 0.20f), 3, { 0, 0 } }};
        melatonin::DropShadow glowCore  = {{ glowColour.withAlpha (isDarkMode ? 0.45f : 0.35f), 2, { 0, 0 } }};
        glowBloom.render (g, halo);
        glowCore.render (g, halo);
    }

    melatonin::DropShadow thumbHi = {{ juce::Colours::white.withAlpha (isDarkMode ? 0.08f : 0.9f), 2, { -1, -1 } }};
    melatonin::DropShadow thumbSh = {{ juce::Colours::black.withAlpha (isDarkMode ? 0.5f : 0.25f), 2, { 1, 1 } }};
    thumbHi.render (g, thumbPath);
    thumbSh.render (g, thumbPath);

    g.setColour (on ? accentColour : base);
    g.fillPath (thumbPath);
    g.setColour (ink.withAlpha (0.16f));
    g.drawEllipse (thumbBounds, 1.0f);

    if (isHighlighted)
    {
        g.setColour (accentColour.withAlpha (0.30f));
        g.strokePath (trackPath, juce::PathStrokeType (1.0f));
    }

    g.setColour (ink.withAlpha (button.isEnabled() ? 0.9f : 0.4f));
    g.setFont (juce::FontOptions ("Helvetica Neue", juce::jmin (12.5f, (float) button.getHeight() * 0.62f), juce::Font::plain));
    g.drawText (button.getButtonText(), button.getLocalBounds().withTrimmedLeft ((int) textLeftInset),
                juce::Justification::centredLeft, true);
}

//==============================================================================
void NeumorphicLookAndFeel::drawComboBox (juce::Graphics& g, int width, int height, bool /*isButtonDown*/,
                                           int /*buttonX*/, int /*buttonY*/, int /*buttonW*/, int /*buttonH*/,
                                           juce::ComboBox& box)
{
    auto bounds = juce::Rectangle<float> (0.0f, 0.0f, (float) width, (float) height).reduced (2.0f);
    auto ink  = getTextColour();
    auto base = getBaseColour();

    juce::Path shape;
    shape.addRoundedRectangle (bounds, 6.0f);

    g.setColour (base);
    g.fillPath (shape);

    melatonin::InnerShadow dark  = {{ juce::Colours::black.withAlpha (isDarkMode ? 0.55f : 0.30f), 5, { 2, 2 } }};
    melatonin::InnerShadow light = {{ juce::Colours::white.withAlpha (isDarkMode ? 0.04f : 0.6f), 5, { -2, -2 } }};
    dark.render (g, shape);
    light.render (g, shape);

    if (box.isPopupActive())
    {
        g.setColour (accentColour.withAlpha (0.5f));
        g.strokePath (shape, juce::PathStrokeType (1.2f));
    }

    float ax = bounds.getRight() - 18.0f, ay = bounds.getCentreY() - 2.0f;
    juce::Path arrow;
    arrow.startNewSubPath (ax, ay);
    arrow.lineTo (ax + 4.0f, ay + 4.0f);
    arrow.lineTo (ax + 8.0f, ay);
    g.setColour (ink.withAlpha (0.5f));
    g.strokePath (arrow, juce::PathStrokeType (1.4f, juce::PathStrokeType::JointStyle::curved,
                                                juce::PathStrokeType::EndCapStyle::rounded));
}

// Give the combo box's internal text label real breathing room on both sides so
// the first glyph never sits on top of the sunken edge.
void NeumorphicLookAndFeel::positionComboBoxText (juce::ComboBox& box, juce::Label& label)
{
    label.setBounds (10, 1, box.getWidth() - 34, box.getHeight() - 2);
    label.setFont (getComboBoxFont (box));
}

// The dropdown list is a separate PopupMenu under the hood -- without these
// overrides it silently falls back to LookAndFeel_V4's own defaults and ignores
// the neumorphic palette entirely.
void NeumorphicLookAndFeel::drawPopupMenuBackground (juce::Graphics& g, int width, int height)
{
    g.setColour (getBaseColour());
    g.fillRect (0, 0, width, height);
    g.setColour (getTextColour().withAlpha (0.14f));
    g.drawRect (0, 0, width, height, 1);
}

void NeumorphicLookAndFeel::drawPopupMenuItem (juce::Graphics& g, const juce::Rectangle<int>& area,
                                                bool isSeparator, bool isActive, bool isHighlighted,
                                                bool isTicked, bool /*hasSubMenu*/, const juce::String& text,
                                                const juce::String& /*shortcutKeyText*/, const juce::Drawable* /*icon*/,
                                                const juce::Colour* /*textColour*/)
{
    auto ink = getTextColour();

    if (isSeparator)
    {
        auto r = area.reduced (6, 0);
        g.setColour (ink.withAlpha (0.12f));
        g.drawLine ((float) r.getX(), (float) r.getCentreY(), (float) r.getRight(), (float) r.getCentreY(), 1.0f);
        return;
    }

    if (isHighlighted && isActive)
    {
        g.setColour (accentColour.withAlpha (0.16f));
        g.fillRoundedRectangle (area.reduced (2).toFloat(), 4.0f);
    }

    auto textArea = area.reduced (12, 0);
    if (isTicked)
    {
        g.setColour (accentColour);
        g.fillEllipse ((float) textArea.getX(), (float) textArea.getCentreY() - 2.5f, 5.0f, 5.0f);
        textArea.removeFromLeft (12);
    }

    g.setColour (isActive ? ink : ink.withAlpha (0.35f));
    g.setFont (juce::FontOptions ("Helvetica Neue", 13.0f, juce::Font::plain));
    g.drawText (text, textArea, juce::Justification::centredLeft, true);
}

//==============================================================================
void NeumorphicLookAndFeel::drawLabel (juce::Graphics& g, juce::Label& label)
{
    g.setColour (label.findColour (juce::Label::textColourId, true).isTransparent()
                     ? getTextColour().withAlpha (0.85f)
                     : label.findColour (juce::Label::textColourId));
    g.setFont (getLabelFont (label));
    g.drawFittedText (label.getText(), label.getLocalBounds(), label.getJustificationType(), 2);
}
